const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function toast(m) {
  const t = $("#toast"); t.textContent = m; t.style.display = "block";
  clearTimeout(toast.h); toast.h = setTimeout(() => t.style.display = "none", 2600);
}

// ---------- التنقل ----------
function go(p) {
  document.querySelectorAll(".page").forEach(e => e.classList.toggle("on", e.id === p));
  document.querySelectorAll("nav button").forEach(b => b.classList.toggle("on", b.dataset.p === p));
  window.scrollTo(0, 0);
}
document.querySelectorAll("nav button").forEach(b => b.onclick = () => go(b.dataset.p));

// ---------- الرئيسية ----------
$("#tag").textContent = APP.tagline;
[["rules", "📜", "القوانين"], ["news", "📢", "الأخبار"], ["apply", "📝", "التقديمات"],
 ["staff", "👑", "الإدارة العليا"], ["creators", "🎬", "صناع المحتوى"], ["ai", "🤖", "DE AI"]]
  .forEach(([p, i, n]) => {
    const b = document.createElement("button");
    b.className = "tile"; b.innerHTML = `<i>${i}</i>${n}`; b.onclick = () => go(p);
    $("#tiles").append(b);
  });

// ---------- القوانين ----------
$("#rulesList").innerHTML = APP.rules.map((r, i) =>
  `<div class="card"><h3><span class="num">${i + 1}</span>${esc(r.t)}</h3><p>${esc(r.d)}</p></div>`).join("");

// ---------- الأخبار ----------
$("#newsList").innerHTML = APP.news.map(n =>
  `<div class="card"><h3>${esc(n.t)}</h3><p>${esc(n.d)}</p><small>${esc(n.date)}</small></div>`).join("");

// ---------- الإدارة ----------
$("#adminList").innerHTML = APP.admins.map(a =>
  `<div class="card crew"><div class="av">${esc(a.name[0])}</div><div><h3 style="margin:0">${esc(a.name)}</h3><span class="tag">${esc(a.role)}</span></div></div>`).join("");

// ---------- صناع المحتوى ----------
$("#creatorList").innerHTML = APP.creators.map(c =>
  `<div class="card crew"><div class="av">${esc(c.n.replace("@", "")[0].toUpperCase())}</div>
   <div style="flex:1"><h3 style="margin:0">${esc(c.n)}</h3><span class="tag">${esc(c.p)}</span></div>
   <a class="btn" href="${esc(c.u)}" target="_blank" rel="noopener">فتح</a></div>`).join("");

// ---------- التقديمات ----------
let job = APP.jobs[0].id;
function chips() {
  const all = [...APP.jobs, { id: "creator", n: "صانع محتوى", i: "🎬" }];
  $("#jobChips").innerHTML = all.map(j =>
    `<button type="button" class="chip ${j.id === job ? "on" : ""}" data-j="${j.id}">${j.i} ${esc(j.n)}</button>`).join("");
  document.querySelectorAll(".chip").forEach(c => c.onclick = () => { job = c.dataset.j; chips(); });
}
chips();
$("#creatorApply").onclick = () => { job = "creator"; chips(); go("apply"); };

$("#form").onsubmit = async e => {
  e.preventDefault();
  const j = [...APP.jobs, { id: "creator", n: "صانع محتوى" }].find(x => x.id === job);
  const text =
`📝 تقديم جديد - ${j.n}
اسم روبلوكس: ${$("#fRoblox").value}
اسم الشخصية: ${$("#fChar").value}
العمر: ${$("#fAge").value}
ديسكورد: ${$("#fDisc").value}
سبب التقديم: ${$("#fWhy").value}
الخبرة: ${$("#fExp").value || "-"}`;
  if (APP.WEBHOOK_URL) {
    try {
      const r = await fetch(APP.WEBHOOK_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: text }) });
      if (!r.ok) throw 0;
      toast("تم إرسال التقديم ✅"); e.target.reset(); return;
    } catch { toast("تعذر الإرسال، راح ننسخ التقديم"); }
  }
  if (navigator.share) { try { await navigator.share({ text }); return; } catch { } }
  try { await navigator.clipboard.writeText(text); toast("تم نسخ التقديم، ارسله للإدارة ✅"); } catch { prompt("انسخ التقديم:", text); }
};

// ---------- الإشعارات ----------
function seen() { return +(localStorage.getItem("seenNews") || 0); }
function checkNews() {
  if (APP.newsVersion > seen() && Notification.permission === "granted") {
    const n = APP.news[0];
    navigator.serviceWorker.ready.then(r => r.showNotification("DE|ريسبكت - " + n.t, { body: n.d, icon: "icons/icon-192.png", dir: "rtl", lang: "ar" }));
    localStorage.setItem("seenNews", APP.newsVersion);
  }
}
$("#bell").onclick = async () => {
  if (!("Notification" in window)) return toast("ثبّت التطبيق من «مشاركة ← إضافة للشاشة الرئيسية» أول");
  const p = await Notification.requestPermission();
  if (p === "granted") { $("#bell").textContent = "🔔 مفعّلة"; toast("تم تفعيل الإشعارات ✅"); checkNews(); }
  else toast("الإشعارات مرفوضة");
};
if ("Notification" in window && Notification.permission === "granted") $("#bell").textContent = "🔔 مفعّلة";

// ---------- DE AI ----------
function localAnswer(q) {
  q = q.toLowerCase();
  if (/قانون|قوانين|rp|ممنوع/.test(q)) return "القوانين:\n" + APP.rules.map((r, i) => `${i + 1}. ${r.t}`).join("\n");
  if (/تقديم|وظيف|انضم|اقدم/.test(q)) return "التقديمات المتاحة: " + APP.jobs.map(j => j.n).join("، ") + "، وصانع محتوى. ادخل قسم التقديمات.";
  if (/ادار|اونر|أونر|فاوندر|مؤسس|مالك/.test(q)) return "الإدارة العليا: " + APP.admins.map(a => `${a.role} ${a.name}`).join(" و ");
  if (/محتوى|ستريم|تويتش|يوتيوب|صانع/.test(q)) return "صناع المحتوى: " + APP.creators.map(c => c.n).join("، ");
  if (/خبر|تحديث|اعلان|إعلان/.test(q)) return "آخر خبر: " + APP.news[0].t + " - " + APP.news[0].d;
  if (/سلام|هلا|مرحب/.test(q)) return "هلا والله! كيف أقدر أخدمك؟";
  return "أنا أجاوب حالياً عن القوانين والتقديمات والإدارة وصناع المحتوى والأخبار. للأسئلة العامة لازم يربط صاحب التطبيق خدمة ذكاء اصطناعي في الإعدادات.";
}
function add(cls, t) {
  const d = document.createElement("div"); d.className = "msg " + cls; d.style.whiteSpace = "pre-wrap"; d.textContent = t;
  $("#chat").append(d); $("#chat").scrollTop = 1e9; return d;
}
$("#aiForm").onsubmit = async e => {
  e.preventDefault();
  const q = $("#aiIn").value.trim(); if (!q) return;
  $("#aiIn").value = ""; add("me", q);
  if (APP.AI_ENDPOINT) {
    const w = add("bot", "...");
    try {
      const r = await fetch(APP.AI_ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: q }) });
      const j = await r.json(); w.textContent = j.reply || j.text || localAnswer(q);
    } catch { w.textContent = localAnswer(q); }
  } else add("bot", localAnswer(q));
};

// ---------- Service Worker ----------
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").then(checkNews).catch(() => { });
